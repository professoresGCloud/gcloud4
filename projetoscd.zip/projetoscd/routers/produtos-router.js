const express = require('express')
const router = express.Router()
//const Produtos = require('../models/produtos-model')
const produtosController = require('../controllers/produtos-controller')
router.get('/', produtosController.listar_produtos)


router.get('/cadastrarProdutos', produtosController.cadastrar_produtos_get)
router.post('/cadastrarProdutos', produtosController.cadastrar_produtos_post)


router.get('/editarProdutos/:id', produtosController.editar_produtos_get)
router.post('/editarProdutos', produtosController.editar_produtos_post)

router.get('/deletarProdutos/:id', produtosController.deletar_produtos)

module.exports = router
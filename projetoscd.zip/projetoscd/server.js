const express = require('express')
const app = express()
const mongoose = require('mongoose')
//const bodyParser = require('body-parser')
const port = 3000

//TEMPLATE ENGINE
app.set('view engine', 'ejs')
app.set('views', __dirname + '/views')

//Body Parser
app.use(express.urlencoded())
app.use(express.json())

//BANCO DE DADOS

mongoose.connect('mongodb+srv://admin:admin@cluster0.y126c.mongodb.net/vendas?retryWrites=true&w=majority', {useNewUrlParser: true, useUnifiedTopology: true})

//Models


//ROTAS
const produtos_router = require('./routers/produtos-router')

app.use('/produtos', produtos_router)

app.get('/', (req, res) => {
	res.send("Página Inicial")
})



//CONEXÃO COM O SERVIDOR
app.listen(port, () => {
	console.log("Servidor rodando na porta 3000")
})
